/**
 * JSON-specific parser and generator implementation classes that
 * Jackson defines and uses.
 * Application code should not (need to) use contents of this package;
 * nor are these implementations likely to be of use for sub-classing.
 */
package com.fasterxml.jackson.core.json;
